<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use App\Http\Requests\MassDestroyCenterRequest;
use App\Http\Requests\StoreCenterRequest;
use App\Http\Requests\UpdateCenterRequest;
use App\Models\Center;
use App\Models\User;
use Gate;
use Illuminate\Http\Request;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use Symfony\Component\HttpFoundation\Response;
use Yajra\DataTables\Facades\DataTables;
use Alert;
use App\Mail\UserAccepted;
use App\Mail\UserRejected;
use Illuminate\Support\Facades\Mail;


class CenterController extends Controller
{
    use MediaUploadingTrait;
    public function index(Request $request)
    {
        abort_if(Gate::denies('center_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if ($request->ajax()) {
            $query = Center::with(['user'])->select(sprintf('%s.*', (new Center)->table));
            $table = Datatables::of($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');

            $table->editColumn('actions', function ($row) {
                $viewGate = 'center_show';
                $editGate = 'center_edit';
                $deleteGate = 'center_delete';
                $crudRoutePart = 'centers';

                return view('partials.datatablesActions', compact(
                    'viewGate',
                    'editGate',
                    'deleteGate',
                    'crudRoutePart',
                    'row'
                ));
            });

            $table->editColumn('id', function ($row) {
                return $row->id ? $row->id : '';
            });
            $table->editColumn('name', function ($row) {
                return $row->name ? $row->name : '';
            });
            $table->editColumn('specialization', function ($row) {
                return $row->specialization ? $row->specialization : '';
            });
            $table->editColumn('experience_years', function ($row) {
                return $row->experience_years ? $row->experience_years : '';
            });
               $table->editColumn('approved', function ($row) {

                if ($row->user?->approved == 1) {
                    return '<span class="badge badge-success">تم القبول</span>';
                }


                $badge = '<span class="badge badge-secondary mb-1 d-block">بانتظار المراجعة</span>';

                $approveBtn = '<a class="btn btn-sm btn-success" href="' . route('admin.associations.approve', $row->id) . '">قبول</a>';

                $rejectBtn = '
        <button class="btn btn-sm btn-danger" data-toggle="modal" data-target="#rejectModal-' . $row->id . '">رفض</button>

        <div class="modal fade" id="rejectModal-' . $row->id . '" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <form method="POST" action="' . route('admin.associations.reject', $row->id) . '">
                    ' . csrf_field() . '
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">سبب الرفض</h5>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <div class="modal-body">
                            <textarea name="reason" class="form-control" required></textarea>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-danger">رفض نهائي</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>';

                return $badge . $approveBtn . ' ' . $rejectBtn;
            });
            $table->editColumn('logo', function ($row) {
                if ($photo = $row->logo) {
                    return sprintf(
                        '<a href="%s" target="_blank"><img src="%s" width="50px" height="50px"></a>',
                        $photo->url,
                        $photo->thumbnail
                    );
                }

                return '';
            });
            $table->editColumn('image', function ($row) {
                if ($photo = $row->image) {
                    return sprintf(
                        '<a href="%s" target="_blank"><img src="%s" width="50px" height="50px"></a>',
                        $photo->url,
                        $photo->thumbnail
                    );
                }

                return '';
            });
            $table->editColumn('license_number', function ($row) {
                return $row->license_number ? $row->license_number : '';
            });
            $table->editColumn('director_name', function ($row) {
                return $row->director_name ? $row->director_name : '';
            });
            $table->editColumn('coordinator_name', function ($row) {
                return $row->coordinator_name ? $row->coordinator_name : '';
            });

            $table->rawColumns(['actions', 'placeholder', 'logo', 'image','approved']);

            return $table->make(true);
        }

        return view('admin.centers.index');
    }


    public function create()
    {
        abort_if(Gate::denies('center_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $users = User::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('admin.centers.create', compact('users'));
    }

    public function store(StoreCenterRequest $request)
    {
        $user = User::create([
            'email' => $request->email,
            'password' => $request->password,
            'user_type' => 'center',
            'approved' => 1,
            'name'=>$request->name
        ]);
        $center = Center::create($request->all());
        $center->user_id = $user->id;
        $center->save();

        if ($request->input('logo', false)) {
            $center->addMedia(storage_path('tmp/uploads/' . basename($request->input('logo'))))->toMediaCollection('logo');
        }

        if ($request->input('image', false)) {
            $center->addMedia(storage_path('tmp/uploads/' . basename($request->input('image'))))->toMediaCollection('image');
        }

        if ($request->input('license_image', false)) {
            $center->addMedia(storage_path('tmp/uploads/' . basename($request->input('license_image'))))->toMediaCollection('license_image');
        }

        if ($media = $request->input('ck-media', false)) {
            Media::whereIn('id', $media)->update(['model_id' => $center->id]);
        }

        Alert::success('اضافة بنجاح', 'تمت الاضافة بنجاح');

        return redirect()->route('admin.centers.index');
    }

    public function edit(Center $center)
    {
        abort_if(Gate::denies('center_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $users = User::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $center->load('user');

        return view('admin.centers.edit', compact('center', 'users'));
    }

    public function update(UpdateCenterRequest $request, Center $center)
    {
        $user = User::find($center->user_id);
        $user->update([
            'email' => $request->email,
            'password' => $request->password,
            'name'=>$request->name
        ]);
        $center->update($request->all());

        if ($request->input('logo', false)) {
            if (!$center->logo || $request->input('logo') !== $center->logo->file_name) {
                if ($center->logo) {
                    $center->logo->delete();
                }
                $center->addMedia(storage_path('tmp/uploads/' . basename($request->input('logo'))))->toMediaCollection('logo');
            }
        } elseif ($center->logo) {
            $center->logo->delete();
        }

        if ($request->input('image', false)) {
            if (!$center->image || $request->input('image') !== $center->image->file_name) {
                if ($center->image) {
                    $center->image->delete();
                }
                $center->addMedia(storage_path('tmp/uploads/' . basename($request->input('image'))))->toMediaCollection('image');
            }
        } elseif ($center->image) {
            $center->image->delete();
        }

        if ($request->input('license_image', false)) {
            if (!$center->license_image || $request->input('license_image') !== $center->license_image->file_name) {
                if ($center->license_image) {
                    $center->license_image->delete();
                }
                $center->addMedia(storage_path('tmp/uploads/' . basename($request->input('license_image'))))->toMediaCollection('license_image');
            }
        } elseif ($center->license_image) {
            $center->license_image->delete();
        }
        Alert::success('تحديث بنجاح', 'تم التحديث بنجاح');

        return redirect()->route('admin.centers.index');
    }

    public function show(Center $center)
    {
        abort_if(Gate::denies('center_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $center->load('user');

        return view('admin.centers.show', compact('center'));
    }

    public function destroy(Center $center)
    {
        abort_if(Gate::denies('center_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $center->delete();

        return back();
    }

    public function massDestroy(MassDestroyCenterRequest $request)
    {
        $centers = Center::find(request('ids'));

        foreach ($centers as $center) {
            $center->delete();
        }

        return response(null, Response::HTTP_NO_CONTENT);
    }

    public function storeCKEditorImages(Request $request)
    {
        abort_if(Gate::denies('center_create') && Gate::denies('center_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $model = new Center();
        $model->id = $request->input('crud_id', 0);
        $model->exists = true;
        $media = $model->addMediaFromRequest('upload')->toMediaCollection('ck-media');

        return response()->json(['id' => $media->id, 'url' => $media->getUrl()], Response::HTTP_CREATED);
    }

    public function approve(Center $center)
    {
        $center->user->approved = 1;
        $center->user->save();

        Mail::to($center->user->email)->send(new UserAccepted($center->user));

        Alert::success('تم القبول', 'تم تفعيل المركز وإرسال الإيميل.');
        return redirect()->back();  
    }

    public function reject(Request $request, Center $center)
    {
        $user = $center->user;
        $reason = $request->input('reason');


        $center->delete();
        $user->forceDelete();

        Mail::to($user->email)->send(new UserRejected($user, $reason));

        Alert::info('تم الرفض', 'تم حذف المركز وإرسال سبب الرفض.');
        return redirect()->back();
    }

}